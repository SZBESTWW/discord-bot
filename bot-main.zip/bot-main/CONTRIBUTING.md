# Contributing Guidelines

The Contributing Guidelines for Python Discord projects can be found [on our website](https://pydis.com/contributing.md).
