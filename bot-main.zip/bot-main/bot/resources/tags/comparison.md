**Assignment vs. Comparison**

The assignment operator (`=`) is used to assign variables.
```python
x = 5
print(x)  # Prints 5
```
The equality operator (`==`) is used to compare values.
```python
if x == 5:
    print("The value of x is 5")
```
